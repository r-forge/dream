# 									Joseph Guillaume
#									John Joseph
#									March 2012
#
# Application of DREAM to SWAT, with Gaussian likelihood function.  
#                                     					                               
# Load dream. This line need not be executed if dream has already been loaded in the  R session.
#
library(dream) 
#
# Load and start the SNOW parallel processing library. This line need not be executed if snow
# has already been loaded in the R session.  Also, set the number of nodes equal to the number
# of MCMC chains to be used.
#
library(snow) 
cl<-makeCluster(8,type="SOCK")   
#
# The number of nodes and MCMC chains (nseq) is set at 8.  
# The Rubin-Gelman convergence criteria (Rthres) is set at 1.2, but 
# if 100,000 simulations have been executed (ndraw) and the Rubin-
# Gelman value still exceeds 1.2 the algorithm will stop anyway. 
# The �snow.chains� method of parallelization should be used (parallel).
#
control<-list(nseq=8,ndraw=100000,Rthres=1.2,parallel="snow.chains") 
#
# The SWAT adjustment parameters and their ranges are shown below for our example.  See pp. 40-43
# of the SWAT-CUP4 user manual (Abbaspour, 2011) for additional guidance.   These parameters must
# appear in the same order as they do in the �model.in.rows�statement.
#
pars<-list("r__CN2.mgt"=c(-0.25,0.25),"v__ESCO.hru"=c(0.9,1.0),"v__GW_REVAP.gw"=c(0.02,0.2),
    "v__CANMX.hru"=c(0.1,10),"v__GW_DELAY.gw"=c(1,50),"r__SOL_Z().sol"=c(-0.25,0.25),
    "v__GWQMN.gw"=c(0,2000),"r__SOL_AWC().sol"=c(-0.25,0.25))
#
# Define the function that will be called by DREAM for every parameter set in every chain.
#
callSWAT<-function(id,pars){
model.in.rows<- c("r__CN2.mgt","v__ESCO.hru","v__GW_REVAP.gw","v__CANMX.hru",
     "v__GW_DELAY.gw","r__SOL_Z().sol","v__GWQMN.gw","r__SOL_AWC().sol")
model.in.file <-as.character(c("LREW1/model.in","LREW2/model.in",
		"LREW3/model.in","LREW4/model.in","LREW5/model.in",
		"LREW6/model.in","LREW7/model.in","LREW8/model.in"))
output.rch.file<-as.character(c("LREW1/output.rch","LREW2/output.rch",
		"LREW3/output.rch","LREW4/output.rch","LREW5/output.rch",
		"LREW6/output.rch","LREW7/output.rch","LREW8/output.rch"))
#    Extract values from the observed data file to create the vector of observed values,
#    and create vector of names of the batch files that will execute SWAT and SWAT_Edit.
Qo<-read.table("Qo.txt")[,1] 
bfname<-as.character(c("runLREW1.bat","runLREW2.bat",
		"runLREW3.bat","runLREW4.bat","runLREW5.bat",
		"runLREW6.bat","runLREW7.bat","runLREW8.bat"))
#    From the parameters given by DREAM, select out the parameter set for this chain.
this.par.set=pars[id,]
#    Set the parameters in SWAT for this instance.
this.file<-model.in.file[id]
output.file<-output.rch.file[id]
write.table(this.par.set,this.file,
	quote=FALSE,row.names=model.in.rows,col.names=FALSE)
# Run the batch script that modifies the parameters and runs the model.
system(bfname[id]) 
# Read the model output.
Qsim.data<-read.table(output.file,skip=9)
Qs<-Qsim.data[Qsim.data$V2==7,6]
# Calculate the log likelihood.  Here we are basing the likelihood function on the 
# Gaussian distribution.  
res<-Qo-Qs
sd.res<-sd(res)
var.res<-var(res)
logp<-sum(sapply(res,function(res_k)
		log((1/(sqrt(2*pi)*sd.res))*exp(-res_k^2/(2*var.res)))))
return(logp)							 
}
#
dream.object<-dream(
	FUN=callSWAT,
	pars=pars,
	func.type="logposterior.density",
	control=control)
summary(dream.object)
## Stop SNOW parallelisation
stopCluster(cl)
#
plot(dream.object)#plots graphs of Markov chains, acceptance rates, etc.
print(coef(dream.object)) #prints the optimal parameter values on console
print(dream.object) #prints the DREAM algorithm parameters used
#
################################  E  N  D  #############################

